import torch

from models.base.fscil_trainer import FSCILTrainer as Trainer
import os.path as osp
import matplotlib.pyplot as plt
import seaborn as sns
import torch.nn as nn
from copy import deepcopy
import itertools
from .helper import *
from utils import *
from dataloader.data_utils import *
from .Network import MYNET
from torch.utils.data import Dataset, DataLoader
from scipy.spatial.distance import pdist, squareform
class FSCILTrainer(Trainer):
    def __init__(self, args):

        super().__init__(args)
        self.args = args
        self.set_save_path()
        self.args = set_up_datasets(self.args)
        self.set_up_model()
        pass

    def set_up_model(self):
        self.model = MYNET(self.args, mode=self.args.base_mode)
        print(MYNET)
        self.model = nn.DataParallel(self.model, list(range(self.args.num_gpu)))
        self.model = self.model.cuda()

        if self.args.model_dir != None:  #
            print('Loading init parameters from: %s' % self.args.model_dir)
            self.best_model_dict = torch.load(self.args.model_dir)['params']
        else:
            print('*********WARNINGl: NO INIT MODEL**********')
            # raise ValueError('You must initialize a pre-trained model')
            pass

    def update_param(self, model, pretrained_dict):
        model_dict = model.state_dict()
        pretrained_dict = {k: v for k, v in pretrained_dict.items()}
        pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict}
        model_dict.update(pretrained_dict)
        model.load_state_dict(model_dict)
        return model

    def get_dataloader(self, session,meta=True):
        if session == 0 and meta==True:
            trainset, trainloader, testloader = self.get_base_dataloader_meta()
        if session == 0 and meta==False:
            trainset, trainloader = self.get_base_dataloader_1()
            return trainset, trainloader
        if session > 0:
            trainset, trainloader, testloader = self.get_new_dataloader(session)

        return trainset, trainloader, testloader

    def get_base_dataloader_meta(self):
        txt_path = "data/index_list/" + self.args.dataset + "/session_" + str(0 + 1) + '.txt'
        class_index = np.arange(self.args.base_class)
        if self.args.dataset == 'mstar':
            trainset = self.args.Dataset.MSTARImageNet(root=self.args.dataroot, train=True, index=class_index, base_sess=True)
            testset = self.args.Dataset.MSTARImageNet(root=self.args.dataroot, train=False, index=class_index)
        if self.args.dataset == 'nwpu':
            trainset = self.args.Dataset.nwpuImageNet(root=self.args.dataroot, train=True, index=class_index, base_sess=True)
            testset = self.args.Dataset.nwpuImageNet(root=self.args.dataroot, train=False, index=class_index)
        # DataLoader(test_set, batch_sampler=sampler, num_workers=8, pin_memory=True)
        sampler = CategoriesSampler(trainset.targets, self.args.train_episode, self.args.episode_way,
                                    self.args.episode_shot + self.args.episode_query)

        trainloader = torch.utils.data.DataLoader(dataset=trainset, batch_sampler=sampler, num_workers=8,
                                                  pin_memory=True)

        testloader = torch.utils.data.DataLoader(
            dataset=testset, batch_size=self.args.test_batch_size, shuffle=False, num_workers=8, pin_memory=True)

        return trainset, trainloader, testloader

    def get_base_dataloader_1(self):

        class_index = np.arange(self.args.base_class)
        if self.args.dataset == 'mstar':
            trainset = self.args.Dataset.MSTARImageNet(root=self.args.dataroot, train=True, index=class_index,
                                                       base_sess=True)
        if self.args.dataset == 'nwpu':
            trainset = self.args.Dataset.nwpuImageNet(root=self.args.dataroot, train=True, index=class_index,
                                                       base_sess=True)

        # DataLoader(test_set, batch_sampler=sampler, num_workers=8, pin_memory=True)
        sampler = CategoriesSampler(trainset.targets, self.args.train_episode, self.args.base_class,
                                    self.args.episode_shot + self.args.episode_query)

        trainloader = torch.utils.data.DataLoader(dataset=trainset, batch_sampler=sampler, num_workers=8,
                                                  pin_memory=True)

        return trainset, trainloader

    def get_new_dataloader(self, session):
        txt_path = "D:/pythondata/BiDistFSCIL-main/BiDistFSCIL-main/data/index_list/" + self.args.dataset + "/session_" + str(session + 1) + '.txt'
        if self.args.dataset == 'mstar':
            trainset = self.args.Dataset.MSTARImageNet(root=self.args.dataroot, train=True,
                                                      index_path=txt_path)
        if self.args.dataset == 'nwpu':
            trainset = self.args.Dataset.nwpuImageNet(root=self.args.dataroot, train=True,
                                                      index_path=txt_path)
        if self.args.batch_size_new == 0:
            batch_size_new = trainset.__len__()
            trainloader = torch.utils.data.DataLoader(dataset=trainset, batch_size=batch_size_new, shuffle=False,
                                                      num_workers=8, pin_memory=True)
        else:
            trainloader = torch.utils.data.DataLoader(dataset=trainset, batch_size=self.args.batch_size_new,
                                                      shuffle=True,
                                                      num_workers=8, pin_memory=True)

        class_new = self.get_session_classes(session)
        if self.args.dataset == 'mstar':
            testset = self.args.Dataset.MSTARImageNet(root=self.args.dataroot, train=False, index=class_new)
        if self.args.dataset == 'nwpu':
            testset = self.args.Dataset.nwpuImageNet(root=self.args.dataroot, train=False, index=class_new)
        testloader = torch.utils.data.DataLoader(dataset=testset, batch_size=self.args.test_batch_size, shuffle=False,
                                                 num_workers=8, pin_memory=True)

        return trainset, trainloader, testloader

    def get_session_classes(self, session):
        class_list = np.arange(self.args.base_class + session * self.args.way)
        return class_list

    def replace_to_rotate(self, proto_tmp, query_tmp):
        for i in range(self.args.low_way):
            # random choose rotate degree
            rot_list = [90, 180, 270]
            sel_rot = random.choice(rot_list)
            if sel_rot == 90:  # rotate 90 degree
                # print('rotate 90 degree')
                proto_tmp[i::self.args.low_way] = proto_tmp[i::self.args.low_way].transpose(2, 3).flip(2)
                query_tmp[i::self.args.low_way] = query_tmp[i::self.args.low_way].transpose(2, 3).flip(2)
            elif sel_rot == 180:  # rotate 180 degree
                # print('rotate 180 degree')
                proto_tmp[i::self.args.low_way] = proto_tmp[i::self.args.low_way].flip(2).flip(3)
                query_tmp[i::self.args.low_way] = query_tmp[i::self.args.low_way].flip(2).flip(3)
            elif sel_rot == 270:  # rotate 270 degree
                # print('rotate 270 degree')
                proto_tmp[i::self.args.low_way] = proto_tmp[i::self.args.low_way].transpose(2, 3).flip(3)
                query_tmp[i::self.args.low_way] = query_tmp[i::self.args.low_way].transpose(2, 3).flip(3)
        return proto_tmp, query_tmp

    def get_optimizer_base(self):

        optimizer = torch.optim.SGD([{'params': self.model.module.encoder.parameters(), 'lr': self.args.lr_base},
                                     {'params': self.model.module.slf_attn.parameters(), 'lr': self.args.lrg}],
                                    momentum=0.9, nesterov=True, weight_decay=self.args.decay)

        if self.args.schedule == 'Step':
            scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=self.args.step, gamma=self.args.gamma)
        elif self.args.schedule == 'Milestone':
            scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=self.args.milestones, gamma=self.args.gamma)

        return optimizer, scheduler

    def get_optimizer_align(self):

        optimizer = torch.optim.SGD([{'params': self.model.module.fc_proto.parameters(), 'lr': self.args.lrg}],
                                    momentum=0.9, nesterov=True, weight_decay=self.args.decay)

        return optimizer

    def train(self):
        args = self.args
        t_start_time = time.time()

        # init train statistics
        result_list = [args]
        self.optimizer_1 = self.get_optimizer_align()

        for session in range(args.start_session, args.sessions):


            train_set, trainloader, testloader = self.get_dataloader(session,meta=True)
            self.model = self.update_param(self.model, self.best_model_dict)
            self.nways_session = args.base_class + session * args.way
            if session == 0:  # load base class train img label

                align(self.model, self.optimizer_1, self.nways_session)
                print('new classes for this session:\n', np.unique(train_set.targets))
                optimizer, scheduler = self.get_optimizer_base()

                for epoch in range(args.epochs_base):
                    start_time = time.time()
                    # train base sess
                    self.model.eval()
                    tl, ta = self.base_train(self.model, trainloader, optimizer, scheduler, epoch, args)

                    self.model = replace_base_fc(train_set, testloader.dataset.transform, self.model, args)  #用原型替代fc的权值

                    self.model.module.mode = 'avg_cos'

                    if args.set_no_val: # set no validation
                        save_model_dir = os.path.join(args.save_path, 'session' + str(session) + '_max_acc.pth')
                        torch.save(dict(params=self.model.state_dict()), save_model_dir)
                        torch.save(optimizer.state_dict(), os.path.join(args.save_path, 'optimizer_best.pth'))
                        self.best_model_dict = deepcopy(self.model.state_dict())
                        tsl, tsa = self.test(self.model, testloader, args, session)
                        self.trlog['test_loss'].append(tsl)
                        self.trlog['test_acc'].append(tsa)
                        lrc = scheduler.get_last_lr()[0]
                        print('epoch:%03d,lr:%.4f,training_loss:%.5f,training_acc:%.5f,test_loss:%.5f,test_acc:%.5f' % (
                            epoch, lrc, tl, ta, tsl, tsa))
                        result_list.append(
                            'epoch:%03d,lr:%.5f,training_loss:%.5f,training_acc:%.5f,test_loss:%.5f,test_acc:%.5f' % (
                                epoch, lrc, tl, ta, tsl, tsa))
                    else:
                        # take the last session's testloader for validation
                        vl, va = self.validation()

                        # save better model
                        if (va * 100) >= self.trlog['max_acc'][session]:
                            self.trlog['max_acc'][session] = float('%.3f' % (va * 100))
                            self.trlog['max_acc_epoch'] = epoch
                            save_model_dir = os.path.join(args.save_path, 'session' + str(session) + '_max_acc.pth')
                            torch.save(dict(params=self.model.state_dict()), save_model_dir)
                            torch.save(optimizer.state_dict(), os.path.join(args.save_path, 'optimizer_best.pth'))
                            self.best_model_dict = deepcopy(self.model.state_dict())
                            print('********A better model is found!!**********')
                            print('Saving model to :%s' % save_model_dir)
                        print('best epoch {}, best val acc={:.3f}'.format(self.trlog['max_acc_epoch'],
                                                                          self.trlog['max_acc'][session]))
                        self.trlog['val_loss'].append(vl)
                        self.trlog['val_acc'].append(va)
                        lrc = scheduler.get_last_lr()[0]
                        print('epoch:%03d,lr:%.4f,training_loss:%.5f,training_acc:%.5f,val_loss:%.5f,val_acc:%.5f' % (
                            epoch, lrc, tl, ta, vl, va))
                        result_list.append(
                            'epoch:%03d,lr:%.5f,training_loss:%.5f,training_acc:%.5f,val_loss:%.5f,val_acc:%.5f' % (
                                epoch, lrc, tl, ta, vl, va))

                    self.trlog['train_loss'].append(tl)
                    self.trlog['train_acc'].append(ta)

                    print('This epoch takes %d seconds' % (time.time() - start_time),
                          '\nstill need around %.2f mins to finish' % (
                                  (time.time() - start_time) * (args.epochs_base - epoch) / 60))
                    scheduler.step()

                # always replace fc with avg mean
                self.model.load_state_dict(self.best_model_dict)
                self.model = replace_base_fc(train_set, testloader.dataset.transform, self.model, args)
                best_model_dir = os.path.join(args.save_path, 'session' + str(session) + '_max_acc.pth')
                print('Replace the fc with average embedding, and save it to :%s' % best_model_dir)
                self.best_model_dict = deepcopy(self.model.state_dict())
                torch.save(dict(params=self.model.state_dict()), best_model_dir)

                self.model.module.mode = 'avg_cos'
                tsl, tsa = self.test(self.model, testloader, args, session)
                self.trlog['max_acc'][session] = float('%.3f' % (tsa * 100))
                print('The test acc of base session={:.3f}'.format(self.trlog['max_acc'][session]))

                result_list.append('Session {}, Test Best Epoch {},\nbest test Acc {:.4f}\n'.format(
                    session, self.trlog['max_acc_epoch'], self.trlog['max_acc'][session], ))



            else:  # incremental learning sessions
                print("training session: [%d]" % session)
                self.model.load_state_dict(self.best_model_dict)

                self.model.module.mode = self.args.new_mode
                self.model.eval()
                trainloader.dataset.transform = testloader.dataset.transform
                self.model.module.update_fc(trainloader, np.unique(train_set.targets), session)

                tsl, tsa = self.test(self.model, testloader, args, session)

                # save better model
                self.trlog['max_acc'][session] = float('%.3f' % (tsa * 100))

                save_model_dir = os.path.join(args.save_path, 'session' + str(session) + '_max_acc.pth')
                torch.save(dict(params=self.model.state_dict()), save_model_dir)
                self.best_model_dict = deepcopy(self.model.state_dict())
                print('Saving model to :%s' % save_model_dir)
                print('  test acc={:.3f}'.format(self.trlog['max_acc'][session]))

                result_list.append('Session {}, Test Best Epoch {},\nbest test Acc {:.4f}\n'.format(
                    session, self.trlog['max_acc_epoch'], self.trlog['max_acc'][session]))

        result_list.append(self.trlog['max_acc'])
        print(self.trlog['max_acc'])

        t_end_time = time.time()
        total_time = (t_end_time - t_start_time) / 60
        result_list.append('Best epoch:%d' % self.trlog['max_acc_epoch'])
        print('Best epoch:', self.trlog['max_acc_epoch'])
        print('Total time used %.2f mins' % total_time)
        save_list_to_txt(os.path.join(args.save_path, 'results.txt'), result_list)

    def validation(self):
        with torch.no_grad():
            model = self.model

            for session in range(1, self.args.sessions):
                train_set, trainloader, testloader = self.get_dataloader(session)
                trainloader.dataset.transform = testloader.dataset.transform
                model.module.mode = 'avg_cos'
                model.eval()
                model.module.update_fc(trainloader, np.unique(train_set.targets), session)
                nways_session=self.nways_session+session*1
                align(model, self.optimizer_1, nways_session)
                vl, va = self.test(model, testloader, self.args, session)

        return vl, va

    def base_train(self, model, trainloader, optimizer, scheduler, epoch, args):
        tl = Averager()
        ta = Averager()

        tqdm_gen = tqdm(trainloader)

        label = torch.arange(args.episode_way + args.low_way).repeat(args.episode_query)
        label = label.type(torch.cuda.LongTensor)

        for i, batch in enumerate(tqdm_gen, 1):
            data, true_label = [_.cuda() for _ in batch]

            k = args.episode_way * args.episode_shot  #15*1
            proto, query = data[:k], data[k:]   #proto：15*3*84*84  query：225*3*84*84  有15类，每个类别16个样本
            # random choose rotate degree
            if args.episode_method=='img_mix':
               proto_tmp, query_tmp=self.img_mix(proto,query,args.episode_way,args.low_way)
            if args.episode_method == 'rotate_degree':
               proto_tmp, query_tmp = self.replace_to_rotate(proto_tmp, query_tmp)

            model.module.mode = 'encoder'
            data = model(data)
            proto_tmp = model(proto_tmp)   #15*512
            query_tmp = model(query_tmp)   #225*512
            data=model.module.fc_proto(data)
            proto_tmp = model.module.fc_proto(proto_tmp)
            query_tmp = model.module.fc_proto(query_tmp)
            # k = args.episode_way * args.episode_shot
            proto, query = data[:k], data[k:]

            proto = proto.view(args.episode_shot, args.episode_way, proto.shape[-1])  #1*15*512
            query = query.view(args.episode_query, args.episode_way, query.shape[-1]) #15*15*512

            proto_tmp = proto_tmp.view(args.low_shot, args.low_way, proto.shape[-1])  #1*15*512
            query_tmp = query_tmp.view(args.episode_query, args.low_way, query.shape[-1]) #15*15*512

            proto = proto.mean(0).unsqueeze(0) #在0维上增加一个维度 1*15*512
            proto_tmp = proto_tmp.mean(0).unsqueeze(0)  #1*15*512

            proto = torch.cat([proto, proto_tmp], dim=1)  #1*30*512
            query = torch.cat([query, query_tmp], dim=1)  #15*30*512

            proto = proto.unsqueeze(0)   #1*1*30*512
            query = query.unsqueeze(0)   #1*15*30*512

            logits = model.module._forward(proto, query)   #450*30
            # if args.cosface== True:
            #     logits_1= self.CosFace(logits,label,args.cosface_m,args.cosface_s)
            #     total_loss=F.cross_entropy(logits_1, label)
            #     #total_loss=self.CosFace_loss(logits,label,args.cosface_m,args.cosface_s)
            # else:
            total_loss = F.cross_entropy(logits, label)  #label：450

            acc = count_acc(logits, label)

            lrc = scheduler.get_last_lr()[0]
            tqdm_gen.set_description(
                'Session 0, epo {}, lrc={:.4f},total loss={:.4f} acc={:.4f}'.format(epoch, lrc, total_loss.item(), acc))
            tl.add(total_loss.item())
            ta.add(acc)

            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
        tl = tl.item()
        ta = ta.item()
        return tl, ta

    def test(self, model, testloader, args, session):
        test_class = args.base_class + session * args.way
        model = model.eval()
        vl = Averager()
        va = Averager()
        with torch.no_grad():
            for i, batch in enumerate(testloader, 1):
                data, test_label = [_.cuda() for _ in batch]

                model.module.mode = 'encoder'
                query = model(data)
                query = model.module.fc_proto(query)
                query = query.unsqueeze(0).unsqueeze(0)

                proto = model.module.fc.weight[:test_class, :].detach()
                proto = model.module.fc_proto(proto)
                proto = proto.unsqueeze(0).unsqueeze(0)

                logits = model.module._forward(proto, query)

                loss = F.cross_entropy(logits, test_label)
                acc = count_acc(logits, test_label)
                vl.add(loss.item())
                va.add(acc)

            vl = vl.item()
            va = va.item()

        return vl, va

    def set_save_path(self):

        self.args.save_path = '%s/' % self.args.dataset
        self.args.save_path = self.args.save_path + '%s/' % self.args.project
        self.args.save_path = self.args.save_path + '%dW-%dS-%dQ-%dEpi-L%dW-L%dS' % (
            self.args.episode_way, self.args.episode_shot, self.args.episode_query, self.args.train_episode,
            self.args.low_way, self.args.low_shot)
        # if self.args.use_euclidean:
        #     self.args.save_path = self.args.save_path + '_L2/'
        # else:
        #     self.args.save_path = self.args.save_path + '_cos/'
        if self.args.schedule == 'Milestone':
            mile_stone = str(self.args.milestones).replace(" ", "").replace(',', '_')[1:-1]
            self.args.save_path = self.args.save_path + 'Epo_%d-Lr1_%.6f-Lrg_%.5f-MS_%s-Gam_%.2f-T_%.2f' % (
                self.args.epochs_base, self.args.lr_base, self.args.lrg, mile_stone, self.args.gamma,
                self.args.temperature)
        elif self.args.schedule == 'Step':
            self.args.save_path = self.args.save_path + 'Epo_%d-Lr1_%.6f-Lrg_%.5f-Step_%d-Gam_%.2f-T_%.2f' % (
                self.args.epochs_base, self.args.lr_base, self.args.lrg, self.args.step, self.args.gamma,
                self.args.temperature)

        if 'ft' in self.args.new_mode:
            self.args.save_path = self.args.save_path + '-ftLR_%.3f-ftEpoch_%d' % (
                self.args.lr_new, self.args.epochs_new)

        if self.args.debug:
            self.args.save_path = os.path.join('debug', self.args.save_path)

        self.args.save_path = os.path.join('checkpoint_revise', self.args.save_path)
        ensure_path(self.args.save_path)
        return None


    def img_mix(self,p,q,episode_way,low_way):

        n= range(episode_way)
        combinations = list(itertools.combinations(n, 2))
        p_tmp=torch.zeros([low_way*1,p.shape[1],p.shape[2],p.shape[3]]).cuda()
        q_tmp = torch.zeros_like(q).cuda()
        for index,i in enumerate(combinations):
            if index > (low_way - 1):
                break
            lamd=(0.7 - 0.3) * torch.rand(1) + 0.3
            lamd=lamd.cuda()
            j,k=i[0],i[1]
            p_tmp[index]= lamd * p[ j ] + (1-lamd) * p[k]
            q_tmp[index::low_way]=lamd*q[j::low_way]+(1-lamd)*q[k::low_way]

        return p_tmp,q_tmp


def align(model,  optimizer,  nways_session):
    '''
    Alignment of FC using MSE Loss and feature replay
    '''
    criterion = myCosineLoss()

    # Stage 1: Compute feature representation of new data
    model.eval()
    model.module.update_feat_replay(nways_session)

    # Stage 2: Compute prototype based on GAAM
    feat, label = model.module.get_feat_replay()
    model.module.reset_prototypes()
    model.module.update_prototypes_feat(feat, label, nways_session)
    cosine_dist = pdist(feat[:nways_session].cpu().numpy(), metric='cosine') #绘制混淆矩阵用
    cosine_similarity=abs(1.1-squareform(cosine_dist))
    plot_metric(cosine_similarity)    #绘制混淆矩阵用
    # Bipolarize prototypes in Mode 2
    if True:
        model.module.bipolarize_prototypes()

    # Stage 4: Update Retraining the FC
    model.module.fc_proto.train()
    for epoch in range(40):
        optimizer.zero_grad()
        support = model.module.get_support_feat(feat)
        loss = criterion(support[:nways_session], model.module.key_mem.data[:nways_session])
        #print('The fc loss is : %.5f' % loss)
        # Backpropagation
        loss.requires_grad_(True)
        loss.backward()
        optimizer.step()

    model.eval()
    model.module.reset_prototypes()
    model.module.update_prototypes_feat(feat,label,nways_session)
    cosine_dist = pdist(support[:nways_session].detach().cpu().numpy(), metric='cosine')  # 绘制混淆矩阵用
    cosine_similarity = abs(1 - squareform(cosine_dist))
    plot_metric(cosine_similarity)  # 绘制混淆矩阵用
class myCosineLoss(nn.Module):
    def __init__(self, rep="real"):
        super(myCosineLoss, self).__init__()

        self.cos = nn.CosineSimilarity()

    def forward(self,a,b):
        sim = self.cos(a, b)
        return -torch.mean(sim)


class myRetrainDataset(Dataset):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]


def plot_metric(metric):
    plt.subplot(1, 1, 1)  # 1行2列的第1个子图
    sns.heatmap(metric, annot=False, fmt=".2f", cmap="Blues", cbar_kws={'label': 'Cosine Distance'},vmin=0, vmax=1)
    plt.title("Cosine Distance Matrix")
    plt.xlabel("Sample Index")
    plt.ylabel("Sample Index")
    plt.show()
    plt.close()