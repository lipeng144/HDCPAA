import torch

import torch.nn as nn
import torch.nn.functional as F
from models.base.Network import MYNET as Net
import numpy as np
import math

class MYNET(Net):

    def __init__(self, args, mode=None):
        super().__init__(args,mode)


        hdim=self.num_features  #512
        self.slf_attn = MultiHeadAttention(1, hdim, hdim, hdim, dropout=0.5)
        self.fc_proto=nn.Linear(hdim,hdim)
        self.feat_replay = torch.zeros((args.num_classes, hdim)).cuda()
        self.label_feat_replay = torch.diag(torch.ones(args.num_classes)).cuda()  # 对角线为1的矩阵，并将其存储在GPU上
    def forward(self, input):
        if self.mode == 'encoder':
            input = self.encode(input)
            return input
        else:
            support_idx, query_idx = input
            logits = self._forward(support_idx, query_idx)
            return logits

    def _forward(self, support,query):

        emb_dim = support.size(-1)
        # get mean of the support
        proto = support.mean(dim=1)   #1*30*512
        num_batch = proto.shape[0]
        num_proto = proto.shape[1]
        num_query = query.shape[1]*query.shape[2]   #num of query*way 30*15=450

        # query: (num_batch, num_query, num_proto, num_emb)
        # proto: (num_batch, num_proto, num_emb)
        query = query.view(-1, emb_dim).unsqueeze(1)  #450*1*512

        proto = proto.unsqueeze(1).expand(num_batch, num_query, num_proto, emb_dim).contiguous() #1*30*512--→1*450*30*512
        proto = proto.view(num_batch*num_query, num_proto, emb_dim)  #450*30*512

        combined = torch.cat([proto, query], 1) # Nk x (N + 1) x d, batch_size = NK #450*31*512
        combined = self.slf_attn(combined, combined, combined)
        # compute distance for all batches
        proto, query = combined.split(num_proto, 1)  #450*30*512，450*1*512

        logits=F.cosine_similarity(query , proto, dim=-1)   #450*30
        logits=logits*self.args.temperature

        return logits


    def reset_prototypes(self):
        if hasattr(self, 'key_mem'):
            self.key_mem.data.fill_(0.0)
        else:
            self.key_mem = nn.parameter.Parameter(torch.zeros(self.args.num_classes, 512),
                                                  requires_grad=False).cuda()
            self.val_mem = nn.parameter.Parameter(torch.diag(torch.ones(self.args.num_classes)), requires_grad=False).cuda()

    def update_prototypes(self, x, y):
        '''
        Update key memory

        Parameters:
        -----------
        x:  Tensor (B,D)
            Input data
        y:  Tensor (B)
            lables
        '''

        support_vec = self.fc_proto(self.encode(x))

        y_onehot = F.one_hot(y, num_classes=self.args.num_classes).float()
        prototype_vec = torch.matmul(torch.transpose(y_onehot, 0, 1), support_vec)
        self.key_mem.data += prototype_vec

    def bipolarize_prototypes(self):
        '''
        Bipolarize key memory
        '''
        self.key_mem.data = torch.sign(self.key_mem.data)


    def update_feat_replay(self, nways):

         self.feat_replay[:nways] = self.fc.weight.data[:nways]

    def get_feat_replay(self):
        return self.feat_replay, self.label_feat_replay

    def update_prototypes_feat(self, feat, y_onehot, nways=None):
        '''
        Update key

        Parameters:
        -----------
        feat:  Tensor (B,d_f)
            Input data
        y:  Tensor (B)
        nways: int
            If none: update all prototypes, if int, update only nwyas prototypes
        '''
        support_vec = self.get_support_feat(feat)
        prototype_vec = torch.matmul(torch.transpose(y_onehot, 0, 1), support_vec)

        if nways is not None:
            self.key_mem.data[:nways] += prototype_vec[:nways]
        else:
            self.key_mem.data += prototype_vec

    def get_support_feat(self, feat):
        '''
        Pass activations through final FC

        Parameters:
        -----------
        feat:  Tensor (B,d_f)
            Input data
        Return:
        ------
        support_vec:  Tensor (B,d)
            Mapped support vectors
        '''
        support_vec = self.fc_proto(feat)
        return support_vec



class ScaledDotProductAttention(nn.Module):
    ''' Scaled Dot-Product Attention '''

    def __init__(self, temperature, attn_dropout=0.1):
        super().__init__()
        self.temperature = temperature
        self.dropout = nn.Dropout(attn_dropout)
        self.softmax = nn.Softmax(dim=2)

    def forward(self, q, k, v):
        attn = torch.bmm(q, k.transpose(1, 2))   ##q：450*31*512 k：450*31*512  attn：450*31*31
        attn = attn / self.temperature
        log_attn = F.log_softmax(attn, 2)
        attn = self.softmax(attn) #会对attn张量的最后一个维度（即第2维）进行softmax操作
        attn = self.dropout(attn)
        output = torch.bmm(attn, v)  #v：450*31*512
        return output, attn, log_attn  #out：450*31*512


class MultiHeadAttention(nn.Module):
    ''' Multi-Head Attention module '''

    def __init__(self, n_head, d_model, d_k, d_v, dropout=0.1):
        super().__init__()
        self.n_head = n_head #1
        self.d_k = d_k #512
        self.d_v = d_v  #512

        self.w_qs = nn.Linear(d_model, n_head * d_k, bias=False)  #512+512
        self.w_ks = nn.Linear(d_model, n_head * d_k, bias=False)
        self.w_vs = nn.Linear(d_model, n_head * d_v, bias=False)
        nn.init.normal_(self.w_qs.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_k)))
        nn.init.normal_(self.w_ks.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_k)))
        nn.init.normal_(self.w_vs.weight, mean=0, std=np.sqrt(2.0 / (d_model + d_v)))

        self.attention = ScaledDotProductAttention(temperature=np.power(d_k, 0.5))
        self.layer_norm = nn.LayerNorm(d_model)

        self.fc = nn.Linear(n_head * d_v, d_model) #512*512
        nn.init.xavier_normal_(self.fc.weight)
        self.dropout = nn.Dropout(dropout)

    def forward(self, q, k, v):
        d_k, d_v, n_head = self.d_k, self.d_v, self.n_head   #512，512，1
        sz_b, len_q, _ = q.size()   #450，31，512
        sz_b, len_k, _ = k.size()  #450，31，512
        sz_b, len_v, _ = v.size()  #450，31，512

        residual = q
        q = self.w_qs(q).view(sz_b, len_q, n_head, d_k)    #450*31*1*512
        k = self.w_ks(k).view(sz_b, len_k, n_head, d_k)    #450*31*1*512
        v = self.w_vs(v).view(sz_b, len_v, n_head, d_v)

        q = q.permute(2, 0, 1, 3).contiguous().view(-1, len_q, d_k)  # (n*b) x lq x dk  #450*31*512
        k = k.permute(2, 0, 1, 3).contiguous().view(-1, len_k, d_k)  # (n*b) x lk x dk  #450*31*512
        v = v.permute(2, 0, 1, 3).contiguous().view(-1, len_v, d_v)  # (n*b) x lv x dv  #450*31*512

        output, attn, log_attn = self.attention(q, k, v)

        output = output.view(n_head, sz_b, len_q, d_v)  #1*450*31*512
        output = output.permute(1, 2, 0, 3).contiguous().view(sz_b, len_q, -1)  # b x lq x (n*dv)450*31*512

        output = self.dropout(self.fc(output))
        output = self.layer_norm(output + residual)

        return output





